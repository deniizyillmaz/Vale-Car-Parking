using UnityEngine;
using UnityEngine.UI;

public class ToggleScript : MonoBehaviour
{
    [Header("Görsel Ayarları")]
    [SerializeField] private Sprite tikliResim; 
    [SerializeField] private Sprite tiksizResim; 

    private Image buttonImage; 

    void Start()
    {
        buttonImage = GetComponent<Image>();
        
        Button btn = GetComponent<Button>();
        if (btn != null)
        {
            // Tıklama olayını kendi fonksiyonumuza bağlıyoruz
            btn.onClick.AddListener(OnButonTiklandi);
        }
        
        // Başlangıçta Butonun Görselini, Yöneticinin Kaydettiği Duruma Göre Ayarla
        GorseliGuncelle();
    }
    
    // Tıklama olayı
    public void OnButonTiklandi()
    {
        // Müzik yöneticisine durumu tersine çevirmesini söyle
        MusicScript.Instance.ToggleMuzik();
        
        // Görseli güncelle
        GorseliGuncelle();
    }

    // Görseli (Butonun Sprite'ını) güncelleyen yardımcı fonksiyon
    private void GorseliGuncelle()
    {
        if (MusicScript.Instance != null && buttonImage != null)
        {
            // Görseli, Yöneticideki güncel duruma göre ayarla
            if (MusicScript.Instance.MuzikAcik && tikliResim != null)
            {
                buttonImage.sprite = tikliResim;
            }
            else if (!MusicScript.Instance.MuzikAcik && tiksizResim != null)
            {
                buttonImage.sprite = tiksizResim;
            }
        }
    }
}
