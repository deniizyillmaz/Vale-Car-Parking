using UnityEngine;
using UnityEngine.Video;
using UnityEngine.SceneManagement;
using System.Collections;

public class MenuScript : MonoBehaviour
{
    [Header("Menu Panelleri")]
    public GameObject mainMenuPanel;
    public GameObject settingsPanel;

    [Header("Intro Video Ayarları")]
    public VideoPlayer introVideoPlayer; // VideoPlayer component
    public GameObject introVideoUI;      // RawImage panel

    void Start()
    {
        // Menü panellerini başlangıçta kapalı yap
        if(mainMenuPanel != null) mainMenuPanel.SetActive(false);
        if(settingsPanel != null) settingsPanel.SetActive(false);

        // Video varsa oynat
        if(introVideoPlayer != null)
            StartCoroutine(PlayIntroVideo());
        else
            // Video yoksa direkt menüyü aç
            if(mainMenuPanel != null) mainMenuPanel.SetActive(true);
    }

    private IEnumerator PlayIntroVideo()
    {
        if(introVideoUI != null)
            introVideoUI.SetActive(true);

        introVideoPlayer.Play();

        // Videonun başlamasını bekle
        yield return new WaitUntil(() => introVideoPlayer.isPlaying);

        bool isFinished = false;
        introVideoPlayer.loopPointReached += (VideoPlayer vp) => { isFinished = true; };

        yield return new WaitUntil(() => isFinished);

        // Video UI gizle
        if(introVideoUI != null)
            introVideoUI.SetActive(false);

        // Menü panellerini aç
        if(mainMenuPanel != null) mainMenuPanel.SetActive(true);
    }

    // Diğer menü fonksiyonları
    public void PlayButton()
    {
        SceneManager.LoadScene("GameScene");
    }

    public void QuitButton()
    {
        SceneManager.LoadScene("SampleScene");
    }

    public void OpenSettings()
    {
        if(mainMenuPanel != null) mainMenuPanel.SetActive(false);
        if(settingsPanel != null) settingsPanel.SetActive(true);
    }

    public void CloseSettings()
    {
        if (settingsPanel != null) settingsPanel.SetActive(false);
        if (mainMenuPanel != null) mainMenuPanel.SetActive(true);
    }
    
}
