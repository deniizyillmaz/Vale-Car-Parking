using UnityEngine;

public class MusicScript : MonoBehaviour
{
    public static MusicScript Instance { get; private set; }

    [SerializeField] private AudioSource muzikKaynak; // Unity arayüzünden sürükleyip bırakılacak
    [SerializeField] private float yuksekSesSeviyesi = 1f; // Müziğin çalacağı maksimum ses seviyesi

    // Müziğin mevcut durumunu sahneler arası korur
    public bool MuzikAcik { get; private set; } = true; 

    void Awake()
    {
        // Singleton Deseni
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); 
            
            if (muzikKaynak != null && muzikKaynak.clip != null)
            {
                // ÖNEMLİ: Müziği sadece bir kez başlatıyoruz ve bir daha asla durdurmuyoruz/durdaklatmıyoruz.
                // Bu, akışın kesintisiz devam etmesini sağlar.
                muzikKaynak.loop = true; // Müziğin bitince tekrar başlaması için (genellikle fon müzikleri böyledir)
                muzikKaynak.Play(); 
                MuzigiKontrolEt(); // Başlangıç ses seviyesini ayarla
            }
        }
        else if (Instance != this)
        {
            Destroy(gameObject);
        }
    }

    // Toggle Butonunun çağıracağı ana fonksiyon
    public void ToggleMuzik()
    {
        MuzikAcik = !MuzikAcik; // Durumu tersine çevir
        MuzigiKontrolEt();
    }

    // Ses seviyesini ayarlayan ana fonksiyon
    private void MuzigiKontrolEt()
    {
        if (muzikKaynak != null)
        {
            if (MuzikAcik)
            {
                // Müzik AÇIKSA: Ses seviyesini maksimuma getir (Örn: 1.0f)
                muzikKaynak.volume = yuksekSesSeviyesi;
                Debug.Log("Müzik Sesi Açıldı.");
            }
            else
            {
                // MÜZİK KAPALIYSA: Ses seviyesini sıfıra indir (Sessiz)
                muzikKaynak.volume = 0f;
                Debug.Log("Müzik Sesi Kısık (Sıfırlandı).");
            }
        }
    }
}
