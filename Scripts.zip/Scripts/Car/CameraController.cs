using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public Transform Car;
    private Rigidbody CarRB;
    public Vector3 offset;
    public float speed;
    void Start()
    {
        CarRB = Car.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void LateUpdate()
    {
        Vector3 carForward=(CarRB.linearVelocity + Car.transform.forward).normalized;
        transform.position = Vector3.Lerp(transform.position, Car.position + Car.transform.TransformVector(offset) + carForward * (-5f), speed * Time.deltaTime);
        transform.LookAt(Car);
    }
}
