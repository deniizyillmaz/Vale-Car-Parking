using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class MobileController : MonoBehaviour
{
    public bool isPressed; // Butonun basılı olup olmadığı
    public float dampenPress = 0f; // Gaz/Fren kuvveti (0.0 ile 1.0 arası)
    public float sensivity = 2f; // Kuvvetin ne hızla artıp azalacağı

    // --- Direksiyon için eklentiler ---
    [Header("Steering")]
    [Tooltip("-1 = full left, 0 = straight, 1 = full right")]
    public float steerInput = 0f; // Direksiyon girişi -1..1 (UI'den set edilecek)
    public Transform frontLeftWheelMesh;  // Görsel ön tekerlek (dönme için)
    public Transform frontRightWheelMesh; // Görsel ön tekerlek (dönme için)
    public float maxSteerAngle = 30f;     // Maksimum direksiyon açısı (derece)

    void Start()
    {
        SetUpButton();
    }

    void Update()
    {
        if (isPressed)
        {
            // Basılıyken kuvveti artır
            dampenPress += sensivity * Time.deltaTime;
        }
        else
        {
            // Basılı değilken kuvveti azalt
            dampenPress -= sensivity * Time.deltaTime;
        }

        // Değeri daima 0.0 ile 1.0 arasında tut
        dampenPress = Mathf.Clamp01(dampenPress);

        // Görsel direksiyon dönüşünü uygula
        ApplyVisualSteer();
    }

    void SetUpButton()
    {
        // EventTrigger kurulumu (butona tıklandığında/bırakıldığında çalışacak)
        EventTrigger trigger = gameObject.AddComponent<EventTrigger>();

        // Buton basılma (PointerDown)
        var pointerDown = new EventTrigger.Entry();
        pointerDown.eventID = EventTriggerType.PointerDown;
        pointerDown.callback.AddListener((e) => onClickDown());

        // Buton bırakılma (PointerUp)
        var pointerUp = new EventTrigger.Entry();
        pointerUp.eventID = EventTriggerType.PointerUp;
        pointerUp.callback.AddListener((e) => onClickUp());

        trigger.triggers.Add(pointerDown);
        trigger.triggers.Add(pointerUp);
    }

    public void onClickDown()
    {
        // Tuşa basıldı
        isPressed = true;
    }
    
    public void onClickUp()
    {
        // Tuş bırakıldı
        isPressed = false;
    }

    // -----------------------
    // Direksiyon API'si
    // -----------------------

    // UI'den veya başka bir script'ten çağır (değer -1..1 arası)
    public void SetSteer(float value)
    {
        steerInput = Mathf.Clamp(value, -1f, 1f);
    }

    // Ön tekerlek görsellerini steerInput'a göre döndürür
    void ApplyVisualSteer()
    {
        if (frontLeftWheelMesh == null && frontRightWheelMesh == null) return;

        float angle = steerInput * maxSteerAngle;

        if (frontLeftWheelMesh != null)
        {
            Vector3 e = frontLeftWheelMesh.localEulerAngles;
            e.y = angle;
            frontLeftWheelMesh.localEulerAngles = e;
        }

        if (frontRightWheelMesh != null)
        {
            Vector3 e = frontRightWheelMesh.localEulerAngles;
            e.y = angle;
            frontRightWheelMesh.localEulerAngles = e;
        }
    }
}