using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CarController : MonoBehaviour
{
    [Header("Wheels")]
    [Space(10)]
    private Rigidbody carRB;
    public WheelColliders Colliders;
    public WheelMeshes Meshes;

    [Header("Car Settings")]
    [Space(10)]
    public float gasInput;
    public float brakeInput;
    public float maxSteeringAngle;
    public float steeringInput;
    public float motorPower;
    public float slipAngle;
    public float brakePower;
    
    // YENİ VİTES DEĞİŞKENLERİ
    [Header("Gear Settings")]
    [Space(10)]
    public string currentGear = "P"; // Başlangıç vitesi P
    [Tooltip("Gaz basılmadığında R ve D'de yavaşça kaymayı sağlayan motor gücü katsayısı.")]
    public float creepMotorPower = 0.05f; // Creep motor gücü

    private float speed;
    public AnimationCurve steeringCurve;

    public MobileController gasPedal;
    public MobileController breakPedal;

    [Header("Mobile Controls")]
    public MobileController mobileController;


    [Header("Lamps")]
    [Space(10)]
    public GameObject frenLambasiSol; 
    public GameObject frenLambasiSag; 
    public GameObject geriVitesLambasiSol; 
    public GameObject geriVitesLambasiSag; 


    void Start()
    {
        carRB = gameObject.GetComponent<Rigidbody>();
    }
    
    // YENİ METOT: GearShifter tarafından çağrılır
    public void SetGear(string gear)
    {
        currentGear = gear;
        Debug.Log("Vites " + currentGear + " konumuna alındı.");
        
        // P'ye geçince aracı anında durdur (Realistik duruş için)
        if (currentGear == "P" && carRB != null)
        {
             carRB.linearVelocity = Vector3.zero;
             carRB.angularVelocity = Vector3.zero;
        }
    }

    // Update is called once per frame
    void Update()
    {
        speed = carRB.linearVelocity.magnitude;
        ApplyWheelPosition();
    }
    
    void FixedUpdate()
    {
        CheckInput();

        ApplySteering();
        ApplyMotor(); // Güncellenmiş ApplyMotor() çağrılacak
        ApplyBrake(); // Güncellenmiş ApplyBrake() çağrılacak
    }

    // GÜNCELLENMİŞ CheckInput METODU (Geri Vites Lambası Değişti)
    void CheckInput()
    {
        // 1. Gaz Girişi (Aynı kalır)
        gasInput = Input.GetAxis("Vertical"); 
        
        if (gasPedal != null && gasPedal.isPressed)
        {
            gasInput += gasPedal.dampenPress;
        }
    
        // 2. Direksiyon Girişi (Aynı kalır)
        steeringInput = Input.GetAxis("Horizontal"); 

        // 3. Fren Girişi ve Fren Lambası (Aynı kalır)
        if (Input.GetKey(KeyCode.Space) || (breakPedal != null && breakPedal.isPressed))
        {
            brakeInput = 1.0f;
            frenLambasiSol.SetActive(true);
            frenLambasiSag.SetActive(true);
        }
        else
        {
            brakeInput = 0.0f;
            frenLambasiSol.SetActive(false);
            frenLambasiSag.SetActive(false);
        }
        

        // 4. slipAngle (Aynı kalır)
        if (carRB.linearVelocity.magnitude > 0.1f)
        {
            slipAngle = Mathf.Abs(Vector3.SignedAngle(transform.forward, carRB.linearVelocity, Vector3.up));
        }
        else
        {
            slipAngle = 0f;
        }

        // 5. Geri Vites Lambası KONTROLÜ (Vites durumuna göre)
        bool isReverse = (currentGear == "R");
        
        // S tuşuna basma kontrolünü kaldırdık, Vites R olduğunda yanacak.
        if(geriVitesLambasiSol != null && geriVitesLambasiSag != null)
        {
            geriVitesLambasiSol.SetActive(isReverse);
            geriVitesLambasiSag.SetActive(isReverse);
        }
    }

    // GÜNCELLENMİŞ ApplyBrake METODU (P vitesi için freni yönetir)
    void ApplyBrake()
    {
        float finalBrakeTorque = brakeInput * brakePower;
        
        // P vitesinde değilsek normal fren uygula
        if (currentGear != "P")
        {
            Colliders.FRWheel.brakeTorque = finalBrakeTorque * 0.7f;
            Colliders.FLWheel.brakeTorque = finalBrakeTorque * 0.7f;
            // Arka tekerlekler için fren ApplyMotor() metodunda yönetilecek
        } 
        else // P'deysek, normal freni devre dışı bırak
        {
            Colliders.FRWheel.brakeTorque = 0f;
            Colliders.FLWheel.brakeTorque = 0f;
        }
    }


    // GÜNCELLENMİŞ ApplyMotor METODU (Vitese göre torku ayarlar)
    void ApplyMotor()
    {
        float finalMotorTorque = 0f;
        float finalGasInput = gasInput;

        // Fren basılıysa, gazı sıfırla (Gaz ve Fren aynı anda olmaz)
        if (brakeInput > 0f) 
        {
            finalGasInput = 0f;
        }

        // Vitese bağlı olmayan arka fren torkunu sıfırla (P'de ayrı tork verilecek)
        Colliders.RRWheel.brakeTorque = 0f; 
        Colliders.RLWheel.brakeTorque = 0f;

        switch (currentGear)
        {
            case "P":
                // P: Park. Motor torku 0.
                finalMotorTorque = 0f;
                // P'de arka tekerleklere çok güçlü fren torku uygula (Şanzıman kilidi simülasyonu)
                Colliders.RRWheel.brakeTorque = brakePower * 10f; 
                Colliders.RLWheel.brakeTorque = brakePower * 10f;
                break;

            case "R":
                // R: Geri.
                if (finalGasInput > 0f)
                {
                    // Gaz basılıysa: Geriye doğru ivmelenme
                    finalMotorTorque = -motorPower * finalGasInput;
                }
                else
                {
                    // Gaz basılı değilse: Yavaşça geri kayma (Creep)
                    finalMotorTorque = -motorPower * creepMotorPower;
                }
                break;

            case "D":
                // D: İleri Sürüş.
                if (finalGasInput > 0f)
                {
                    // Gaz basılıysa: İleri ivmelenme
                    finalMotorTorque = motorPower * finalGasInput;
                }
                else
                {
                    // Gaz basılı değilse: Yavaşça ileri kayma (Creep)
                    finalMotorTorque = motorPower * creepMotorPower;
                }
                break;
            
            default: 
                finalMotorTorque = 0f;
                break;
        }
        
        // Uygulanan torku tekerleklere uygula
        Colliders.RRWheel.motorTorque = finalMotorTorque;
        Colliders.RLWheel.motorTorque = finalMotorTorque;
        
        // Eğer P'de değilsek, normal fren (arka tekerlek) torkunu uygula (ApplyBrake metodundaki ön frenle beraber çalışır)
        if (currentGear != "P")
        {
             Colliders.RRWheel.brakeTorque += brakeInput * brakePower * 0.3f;
             Colliders.RLWheel.brakeTorque += brakeInput * brakePower * 0.3f;
        }
    }


   void ApplySteering()
{
    // Eğer mobil controller varsa, ondan direksiyon girdisini al
    float finalSteerInput = steeringInput; // varsayılan: klavye
    if (mobileController != null)
        finalSteerInput = mobileController.steerInput; // mobil direksiyon

    float steeringAngle = -finalSteerInput * maxSteeringAngle;
    Colliders.FRWheel.steerAngle = steeringAngle;
    Colliders.FLWheel.steerAngle = steeringAngle;
}
    void ApplyWheelPosition()
    {
        UpdateWheel(Colliders.FLWheel, Meshes.FLWheel);
        UpdateWheel(Colliders.FRWheel, Meshes.FRWheel);
        UpdateWheel(Colliders.RLWheel, Meshes.RLWheel);
        UpdateWheel(Colliders.RRWheel, Meshes.RRWheel);
    }
    void UpdateWheel(WheelCollider coll, MeshRenderer mesh)
    {
        Quaternion rot;
        Vector3 pos;
        coll.GetWorldPose(out pos, out rot);
        mesh.transform.position = pos;
        mesh.transform.rotation = rot;
    }
    
    [System.Serializable]
    public class WheelColliders
    {
        public WheelCollider FLWheel;
        public WheelCollider FRWheel;
        public WheelCollider RLWheel;
        public WheelCollider RRWheel;
    }

    [System.Serializable]
    public class WheelMeshes
    {
        public MeshRenderer FLWheel;
        public MeshRenderer FRWheel;
        public MeshRenderer RLWheel;
        public MeshRenderer RRWheel;
    }
}
