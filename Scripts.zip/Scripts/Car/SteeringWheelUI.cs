using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;

public class SteeringWheelUI : MonoBehaviour, IDragHandler, IBeginDragHandler, IEndDragHandler
{
    [Header("Link")]
    public MobileController mobileController; // direksiyonun bağlı olduğu script

    [Header("Settings")]
    [Tooltip("Toplam dönüş açısı (örnek: 270 = 1.5 tur)")]
    public float maxSteerAngle = 270f; 
    [Tooltip("Bırakınca merkeze dönme hızı")]
    public float returnSpeed = 300f;   
    [Tooltip("Direksiyon tersse işaretle")]
    public bool invertSteer = false;   

    private float currentAngle = 0f;       // anlık direksiyon açısı
    private float lastAngle = 0f;          // önceki karedeki açı
    private bool isDragging = false;       
    private Vector2 centerPoint;           // direksiyon merkezi (ekran pozisyonu)
    private RectTransform rectTransform;
    private Coroutine returnRoutine = null;

    void Start()
    {
        rectTransform = GetComponent<RectTransform>();
    }

    // Parmağı bastığımız anda çalışır
    public void OnBeginDrag(PointerEventData eventData)
    {
        isDragging = true;
        centerPoint = RectTransformUtility.WorldToScreenPoint(eventData.pressEventCamera, rectTransform.position);
        lastAngle = GetAngle(eventData.position);

        if (returnRoutine != null)
        {
            StopCoroutine(returnRoutine);
            returnRoutine = null;
        }
    }

    // Parmağımızı döndürürken çalışır
    public void OnDrag(PointerEventData eventData)
    {
        float newAngle = GetAngle(eventData.position);
        float delta = Mathf.DeltaAngle(lastAngle, newAngle); // açı farkı
        lastAngle = newAngle;

        currentAngle += delta;
        currentAngle = Mathf.Clamp(currentAngle, -maxSteerAngle, maxSteerAngle);

        // Görsel direksiyon dönüşü (doğru yön)
        rectTransform.localRotation = Quaternion.Euler(0f, 0f, currentAngle);

        // Arabaya -1..1 arası değer gönder
        float normalized = currentAngle / maxSteerAngle;
        if (invertSteer) normalized = -normalized;
        if (mobileController != null)
            mobileController.SetSteer(normalized);
    }

    // Parmağı bıraktığımızda çalışır
    public void OnEndDrag(PointerEventData eventData)
    {
        isDragging = false;

        // Merkeze dönmeyi başlat
        if (returnRoutine != null) StopCoroutine(returnRoutine);
        returnRoutine = StartCoroutine(ReturnToCenter());
    }

    // Direksiyonun merkeze dönme hareketi
    IEnumerator ReturnToCenter()
    {
        while (Mathf.Abs(currentAngle) > 0.1f)
        {
            // Açıyı sıfıra doğru düzgün biçimde azalt
            currentAngle = Mathf.MoveTowards(currentAngle, 0f, returnSpeed * Time.unscaledDeltaTime);

            // Görseli güncelle
            rectTransform.localRotation = Quaternion.Euler(0f, 0f, currentAngle);

            // Arabaya değeri gönder
            float normalized = currentAngle / maxSteerAngle;
            if (invertSteer) normalized = -normalized;
            if (mobileController != null)
                mobileController.SetSteer(normalized);

            yield return null;
        }

        // Son olarak tamamen sıfırla
        currentAngle = 0f;
        rectTransform.localRotation = Quaternion.identity;
        if (mobileController != null)
            mobileController.SetSteer(0f);
        returnRoutine = null;
    }

    // Parmağın ekrandaki açısını hesaplar
    private float GetAngle(Vector2 pointerPos)
    {
        Vector2 dir = pointerPos - centerPoint;
        return Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
    }
}