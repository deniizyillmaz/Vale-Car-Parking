using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

// Hem sürüklemeyi başlatma hem de sürüklemeyi bitirme olaylarını dinler
public class GearShifter : MonoBehaviour, IDragHandler, IEndDragHandler
{
    // YENİ EKLE: CarController scriptine erişim için
    public CarController carController; 

    // === Inspector'dan Atanacak Değişkenler ===
    
    // 1. Vites Topuzunun Rect Transform'u (Bu scriptin eklendiği objenin kendisi)
    public RectTransform shifterKnob; 
    
    // 2. Vites Panelinin Rect Transform'u (Sınırları belirlemek için)
    public RectTransform gearPanel; 

    // P, R, D harflerinin olduğu yerlerin Y koordinatları. (ÖNEMLİ: Kendi değerlerinizle güncelleyin!)
    public float pY_Position = 150f; 
    public float rY_Position = 0f;   
    public float dY_Position = -150f; 


    void Start()
    {
        // Başlangıçta topuzu P konumuna ayarla
        if (shifterKnob != null)
        {
            shifterKnob.anchoredPosition = new Vector2(shifterKnob.anchoredPosition.x, pY_Position);
            
            // Başlangıç vitesini CarController'a bildir
            if (carController != null) 
            {
                carController.SetGear(GetCurrentGear(pY_Position));
            }
        }
        else
        {
            Debug.LogError("GearShifter: Shifter Knob atanmamış! Lütfen Inspector'dan atayın.");
        }
    }

    // Fare sürüklenirken bu fonksiyon çağrılır
    public void OnDrag(PointerEventData eventData)
    {
        if (gearPanel == null || shifterKnob == null) return;

        // Fare pozisyonunu Canvas'ın yerel koordinatlarına çevir
        Vector2 localCursor;
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(gearPanel, eventData.position, eventData.pressEventCamera, out localCursor))
            return;

        // Vites topuzunun yeni Y pozisyonunu hesapla
        float newY = localCursor.y;

        // Vites topuzunun hareket aralığını P ve D pozisyonları arasına sınırla
        newY = Mathf.Clamp(newY, dY_Position, pY_Position); 

        // Vites topuzunun pozisyonunu güncelle
        shifterKnob.anchoredPosition = new Vector2(shifterKnob.anchoredPosition.x, newY);
    }

    // Fare sürüklenmeyi bitirdiğinde (bırakıldığında) bu fonksiyon çağrılır
    public void OnEndDrag(PointerEventData eventData)
    {
        if (shifterKnob == null) return;
        
        // Vites topuzunu en yakın vites konumuna (P, R veya D) otomatik olarak kilitle (snap)
        float targetY = GetSnapPosition(shifterKnob.anchoredPosition.y);
        shifterKnob.anchoredPosition = new Vector2(shifterKnob.anchoredPosition.x, targetY);
        
        // Vites durumunu CarController scriptine bildir (EN ÖNEMLİ KISIM)
        string newGear = GetCurrentGear(targetY);
        
        if (carController != null)
        {
            carController.SetGear(newGear); // CarController içindeki SetGear metodunu çağır
        }
        
        Debug.Log("Vites " + newGear + " konumuna kilitlendi.");
    }

    // Mevcut Y pozisyonuna en yakın vites konumunun Y değerini döndürür
    private float GetSnapPosition(float currentY)
    {
        float distP = Mathf.Abs(currentY - pY_Position);
        float distR = Mathf.Abs(currentY - rY_Position);
        float distD = Mathf.Abs(currentY - dY_Position);

        // En kısa mesafeye sahip konumu döndür
        if (distP <= distR && distP <= distD)
            return pY_Position;
        else if (distR <= distP && distR <= distD)
            return rY_Position;
        else
            return dY_Position;
    }
    
    // Kilitleme (snap) sonrası hangi viteste olduğumuzu döndürür
    private string GetCurrentGear(float snapY)
    {
        // Hassasiyet için küçük bir tolerans (0.1f) kullanıyoruz.
        if (Mathf.Abs(snapY - pY_Position) < 0.1f) return "P";
        if (Mathf.Abs(snapY - rY_Position) < 0.1f) return "R";
        if (Mathf.Abs(snapY - dY_Position) < 0.1f) return "D";
        return "N"; // Bilinmeyen bir pozisyon
    }
}
